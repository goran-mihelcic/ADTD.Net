using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Mihelcic.Net.Visio")]
[assembly: AssemblyDescription("Arrange Diagram and generates Visio document")]
[assembly: AssemblyConfiguration("")]

[assembly: AssemblyVersion("2.0.0.16")]
[assembly: AssemblyCompany("Mihelcic.net")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: ComVisible(false)]
