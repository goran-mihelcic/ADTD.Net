﻿namespace Mihelcic.Net.Visio.Arrange
{
    /// <summary>
    /// Layout types
    /// </summary>
    public enum LayoutType
    {
        Node,
        Web,
        Matrix,
        Stack
    }
}
