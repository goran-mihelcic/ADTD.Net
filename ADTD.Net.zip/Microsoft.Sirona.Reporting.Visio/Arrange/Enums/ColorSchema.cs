﻿namespace Mihelcic.Net.Visio.Arrange
{
    /// <summary>
    /// Color schemas
    /// </summary>
    public enum ColorSchema
    {
        AllColors,
        VividColors,
        DarkColors,
        LightColors
    }
}
