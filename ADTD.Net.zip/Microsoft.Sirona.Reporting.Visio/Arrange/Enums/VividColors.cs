﻿namespace Mihelcic.Net.Visio.Arrange
{
    /// <summary>
    /// 16 Vivid Colors
    /// </summary>
    public enum VividColors
    {
        Coral,
        Cyan,
        DeepPink,
        Fuchsia,
        Gold,
        GreenYellow,
        Magenta,
        Orange,
        OrangeRed,
        Orchid,
        Red,
        RoyalBlue,
        Tomato,
        Turquoise,
        Violet,
        Yellow
    }
}
