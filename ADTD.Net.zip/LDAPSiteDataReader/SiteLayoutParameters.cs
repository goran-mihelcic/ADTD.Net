﻿namespace Mihelcic.Net.Visio.Data
{
    internal class SiteLayoutParameters:dxLayoutParameters
    {
        internal SiteLayoutParameters()
        {
            this.HorizontalDistance = 18;
        }
    }
}
