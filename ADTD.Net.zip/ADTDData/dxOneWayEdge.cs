﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.ADTD.Data
{
    //public class dxOneWayEdge : dxEdge
    //{
    //    private string _from;
    //    public string From
    //    {
    //        get { return _from; }
    //        set { _from = value; }
    //    }

    //    private dxNode _fromNode;
    //    public dxNode FromNode
    //    {
    //        get { return _fromNode; }
    //        set { _fromNode = value; }
    //    }

    //    public dxOneWayEdge(string newId, string newName, string type, string from)
    //        : base(newId, newName, type)
    //    {
    //        _from = from;
    //    }
    //}
}
